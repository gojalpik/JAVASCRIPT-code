var attempt = 3; 
function validate(){
var username = document.getElementById("username").value
var password = document.getElementById("password").value;
if ( username == "gojal" && password == "1705032"){
alert ("Login successfully");
//document.form_id.action="reg.html"...if gn form id
window.location.href = "reg.html?uname="+username;
return false;
}
else{
attempt --;
alert("You have left "+attempt+" attempt;");
if( attempt == 0){
document.getElementById("username").disabled = true;
document.getElementById("password").disabled = true;
document.getElementById("submit").disabled = true;
return false;
}
}
}
