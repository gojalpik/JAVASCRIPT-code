var $gallerly = document.querySelector("#gallerly");
var gallerly = new Gallerly($gallerly);
